<!-- This page should be deleted after sometime (Allowing search engines
to update links) -->
<meta http-equiv="refresh" content="3; url=http://mxnet.io/install/index.html" />
<!-- Just in case redirection does not work -->
<p>
  <a href="http://mxnet.io/install/index.html">
    This content is moved to a new MXNet install page. Redirecting... </a>
</p>
