# Join MXNet Development Discussion

Converse with the MXNet community via the following channels:

- [MXNet Apache mailing list](https://lists.apache.org/list.html?dev@mxnet.apache.org) (dev@mxnet.apache.org): To subscribe, send an email to <a href="mailto:dev-subscribe@mxnet.apache.org">dev-subscribe@mxnet.apache.org</a>.
- [MXNet Slack channel](https://apache-mxnet.slack.com): To request an invitation to the channel please subscribe to the mailing list above and then email: <a href="mailto:dev@mxnet.apache.org">dev@mxnet.apache.org</a>. Note: if you have an email address with apache.org, you do not need an approval to join the MXNet Slack channel.
