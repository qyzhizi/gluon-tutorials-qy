# MXNet - C++ API

For namespaces, classes, and code files for the MXNet C++ package, see the  following:

* [Namespaces](http://mxnet.io/doxygen/namespaces.html)
* [Classes](http://mxnet.io/doxygen/annotated.html)
* [Code Files](http://mxnet.io/doxygen/files.html)
* [MXNet CPP Package](https://github.com/dmlc/mxnet/tree/master/cpp-package)
